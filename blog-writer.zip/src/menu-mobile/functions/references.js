
// references module
const references = {
    mobile_menu_container : null,
    sidebar_menu_closer : null
};


export default references;