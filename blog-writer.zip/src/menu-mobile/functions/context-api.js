import {createContext} from '@wordpress/element';

// 
export const ContextAttributes = createContext();