<?php

namespace WpLover\BlogWriter\Inc\Base;

// Exit if access directly
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * @package BaseController
 * 
 * version 1.0
 */

class BaseController
{
    
    function __construct()
    {
        // still not using but in the future
        // it will be used.
    }
}