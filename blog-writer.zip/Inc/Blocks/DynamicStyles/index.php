<?php

//  silence is golden